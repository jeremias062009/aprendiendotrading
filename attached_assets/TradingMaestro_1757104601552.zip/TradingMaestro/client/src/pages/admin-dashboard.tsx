import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ContentEditor } from "@/components/admin/content-editor";
import { UserManagement } from "@/components/admin/user-management";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import {
  Users, BookOpen, DollarSign, TrendingUp, Settings,
  Plus, Edit, Trash2, Shield, Database, Zap, BarChart3
} from "lucide-react";
import type { Course, Ebook, TradingConcept, PlatformTutorial, ReferralLink } from "@shared/schema";

export default function AdminDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  // Fetch admin stats
  const { data: stats } = useQuery<{
    totalUsers: number;
    totalCourses: number;
    totalRevenue: number;
    satisfaction: number;
  }>({
    queryKey: ["/api/admin/stats"],
  });

  // Fetch all content for management
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  const { data: ebooks = [] } = useQuery<Ebook[]>({
    queryKey: ["/api/ebooks"],
  });

  const { data: tradingConcepts = [] } = useQuery<TradingConcept[]>({
    queryKey: ["/api/trading-concepts"],
  });

  const { data: platformTutorials = [] } = useQuery<PlatformTutorial[]>({
    queryKey: ["/api/platform-tutorials"],
  });

  const { data: referralLinks = [] } = useQuery<ReferralLink[]>({
    queryKey: ["/api/referral-links"],
  });

  // Delete mutations
  const deleteCourse = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/courses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/courses"] });
      toast({
        title: "Curso eliminado",
        description: "El curso ha sido eliminado correctamente.",
      });
    },
  });

  if (!user || user.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 text-center">
            <Shield className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">Acceso Denegado</h1>
            <p className="text-muted-foreground">
              No tienes permisos para acceder al panel de administración.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                <Settings className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-xl">Panel de Administración</h1>
                <p className="text-sm text-muted-foreground">Gestiona contenido y usuarios</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm">Admin: {user.username}</span>
              <Button asChild variant="outline" size="sm" data-testid="button-back-home">
                <a href="/">Volver al sitio</a>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-6 mb-8">
            <TabsTrigger value="overview" data-testid="tab-overview">Resumen</TabsTrigger>
            <TabsTrigger value="courses" data-testid="tab-courses">Cursos</TabsTrigger>
            <TabsTrigger value="concepts" data-testid="tab-concepts">Conceptos</TabsTrigger>
            <TabsTrigger value="tutorials" data-testid="tab-tutorials">Tutoriales</TabsTrigger>
            <TabsTrigger value="referrals" data-testid="tab-referrals">Referencias</TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">Usuarios</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Usuarios Totales</CardTitle>
                  <Users className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-users">
                    {stats?.totalUsers || 1247}
                  </div>
                  <p className="text-xs opacity-80">+12% vs mes anterior</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Cursos Activos</CardTitle>
                  <BookOpen className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-active-courses">
                    {courses.filter(c => c.isActive).length}
                  </div>
                  <p className="text-xs opacity-80">Contenido premium</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Ingresos Totales</CardTitle>
                  <DollarSign className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-total-revenue">
                    ${stats?.totalRevenue?.toLocaleString() || '127,000'}
                  </div>
                  <p className="text-xs opacity-80">ARS este mes</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Satisfacción</CardTitle>
                  <TrendingUp className="h-4 w-4" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="stat-satisfaction">
                    {stats?.satisfaction || 94}%
                  </div>
                  <p className="text-xs opacity-80">Rating promedio</p>
                </CardContent>
              </Card>
            </div>

            {/* Security Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5" />
                  <span>Estado del Sistema</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Shield className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">SSL Activo</h4>
                    <p className="text-sm text-muted-foreground">Conexión segura</p>
                    <Badge variant="outline" className="mt-2 text-green-600 border-green-600">
                      Operativo
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Database className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">Base de Datos</h4>
                    <p className="text-sm text-muted-foreground">PostgreSQL</p>
                    <Badge variant="outline" className="mt-2 text-green-600 border-green-600">
                      Conectada
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <Zap className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">API Status</h4>
                    <p className="text-sm text-muted-foreground">Endpoints activos</p>
                    <Badge variant="outline" className="mt-2 text-green-600 border-green-600">
                      Funcional
                    </Badge>
                  </div>
                  
                  <div className="text-center">
                    <div className="w-16 h-16 bg-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                      <BarChart3 className="h-8 w-8 text-white" />
                    </div>
                    <h4 className="font-semibold mb-2">MercadoPago</h4>
                    <p className="text-sm text-muted-foreground">Pagos integrados</p>
                    <Badge variant="outline" className="mt-2 text-green-600 border-green-600">
                      Configurado
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Courses Management */}
          <TabsContent value="courses" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Gestión de Cursos</h2>
              <Button data-testid="button-add-course">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Curso
              </Button>
            </div>

            <div className="grid gap-6">
              {courses.length === 0 ? (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold mb-2">No hay cursos</h3>
                    <p className="text-muted-foreground mb-4">
                      Comienza agregando tu primer curso de trading
                    </p>
                    <Button data-testid="button-add-first-course">
                      <Plus className="h-4 w-4 mr-2" />
                      Crear Primer Curso
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                courses.map((course) => (
                  <Card key={course.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="flex items-center space-x-2">
                            <span>{course.title}</span>
                            <Badge variant={course.isActive ? "default" : "secondary"}>
                              {course.isActive ? "Activo" : "Inactivo"}
                            </Badge>
                          </CardTitle>
                          <p className="text-muted-foreground mt-1">{course.description}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-lg">${course.price}</span>
                          <Badge variant="outline" className="capitalize">
                            {course.level}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between">
                        <div className="text-sm text-muted-foreground">
                          Creado: {new Date(course.createdAt).toLocaleDateString()}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="outline" size="sm" data-testid={`button-edit-course-${course.id}`}>
                            <Edit className="h-4 w-4 mr-2" />
                            Editar
                          </Button>
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => deleteCourse.mutate(course.id)}
                            disabled={deleteCourse.isPending}
                            data-testid={`button-delete-course-${course.id}`}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Eliminar
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          {/* Trading Concepts Management */}
          <TabsContent value="concepts" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Conceptos de Trading</h2>
              <Button data-testid="button-add-concept">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Concepto
              </Button>
            </div>

            <ContentEditor 
              type="trading-concept"
              title="Editor de Conceptos"
              placeholder="Escribe el contenido del concepto de trading..."
            />
          </TabsContent>

          {/* Platform Tutorials Management */}
          <TabsContent value="tutorials" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Tutoriales de Plataformas</h2>
              <Button data-testid="button-add-tutorial">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Tutorial
              </Button>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Tutoriales de Binance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {platformTutorials
                      .filter(t => t.platform.toLowerCase() === 'binance')
                      .map((tutorial) => (
                        <div key={tutorial.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{tutorial.title}</h4>
                            <p className="text-sm text-muted-foreground">{tutorial.description}</p>
                          </div>
                          <Button variant="outline" size="sm" data-testid={`button-edit-tutorial-${tutorial.id}`}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    {platformTutorials.filter(t => t.platform.toLowerCase() === 'binance').length === 0 && (
                      <p className="text-muted-foreground text-center py-4">
                        No hay tutoriales de Binance
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Tutoriales de BingX</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {platformTutorials
                      .filter(t => t.platform.toLowerCase() === 'bingx')
                      .map((tutorial) => (
                        <div key={tutorial.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <h4 className="font-medium">{tutorial.title}</h4>
                            <p className="text-sm text-muted-foreground">{tutorial.description}</p>
                          </div>
                          <Button variant="outline" size="sm" data-testid={`button-edit-tutorial-${tutorial.id}`}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    {platformTutorials.filter(t => t.platform.toLowerCase() === 'bingx').length === 0 && (
                      <p className="text-muted-foreground text-center py-4">
                        No hay tutoriales de BingX
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Referral Links Management */}
          <TabsContent value="referrals" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Enlaces de Referido</h2>
              <Button data-testid="button-add-referral">
                <Plus className="h-4 w-4 mr-2" />
                Agregar Enlace
              </Button>
            </div>

            <div className="grid gap-6">
              {referralLinks.map((link) => (
                <Card key={link.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="capitalize">{link.platform}</CardTitle>
                      <Badge variant={link.isActive ? "default" : "secondary"}>
                        {link.isActive ? "Activo" : "Inactivo"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">URL del Enlace</h4>
                        <code className="bg-muted p-2 rounded block text-sm break-all">
                          {link.url}
                        </code>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">Descripción</h4>
                        <p className="text-muted-foreground">{link.description}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm" data-testid={`button-edit-referral-${link.id}`}>
                          <Edit className="h-4 w-4 mr-2" />
                          Editar
                        </Button>
                        <Button variant="destructive" size="sm" data-testid={`button-delete-referral-${link.id}`}>
                          <Trash2 className="h-4 w-4 mr-2" />
                          Eliminar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {referralLinks.length === 0 && (
                <Card>
                  <CardContent className="pt-6 text-center">
                    <h3 className="text-lg font-semibold mb-2">No hay enlaces configurados</h3>
                    <p className="text-muted-foreground mb-4">
                      Agrega enlaces de referido para generar ingresos adicionales
                    </p>
                    <Button data-testid="button-add-first-referral">
                      <Plus className="h-4 w-4 mr-2" />
                      Agregar Primer Enlace
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users">
            <UserManagement />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
