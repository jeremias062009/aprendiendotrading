import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, ChartLine, TrendingUp, DollarSign, Shield, Users, Award } from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, isLoading, loginMutation, registerMutation } = useAuth();
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [registerForm, setRegisterForm] = useState({ 
    username: "", 
    email: "", 
    password: "",
    confirmPassword: ""
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Redirect if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      setLocation("/");
    }
  }, [user, isLoading, setLocation]);

  const validateLogin = () => {
    const newErrors: Record<string, string> = {};
    
    if (!loginForm.email) {
      newErrors.email = "El email es requerido";
    } else if (!/\S+@\S+\.\S+/.test(loginForm.email)) {
      newErrors.email = "Email no válido";
    }
    
    if (!loginForm.password) {
      newErrors.password = "La contraseña es requerida";
    } else if (loginForm.password.length < 6) {
      newErrors.password = "La contraseña debe tener al menos 6 caracteres";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateRegister = () => {
    const newErrors: Record<string, string> = {};
    
    if (!registerForm.username) {
      newErrors.username = "El nombre de usuario es requerido";
    } else if (registerForm.username.length < 3) {
      newErrors.username = "El nombre de usuario debe tener al menos 3 caracteres";
    }
    
    if (!registerForm.email) {
      newErrors.email = "El email es requerido";
    } else if (!/\S+@\S+\.\S+/.test(registerForm.email)) {
      newErrors.email = "Email no válido";
    }
    
    if (!registerForm.password) {
      newErrors.password = "La contraseña es requerida";
    } else if (registerForm.password.length < 6) {
      newErrors.password = "La contraseña debe tener al menos 6 caracteres";
    }
    
    if (registerForm.password !== registerForm.confirmPassword) {
      newErrors.confirmPassword = "Las contraseñas no coinciden";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateLogin()) {
      loginMutation.mutate(loginForm);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateRegister()) {
      registerMutation.mutate({
        username: registerForm.username,
        email: registerForm.email,
        password: registerForm.password,
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Verificando autenticación...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary via-primary/90 to-accent">
      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
          {/* Hero Section */}
          <div className="text-white space-y-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center">
                  <ChartLine className="h-8 w-8 text-primary" />
                </div>
                <span className="font-bold text-2xl">Aprendiendo Trading</span>
              </div>
              
              <h1 className="font-bold text-4xl lg:text-5xl leading-tight">
                Únete a la Comunidad de 
                <span className="text-accent block">Traders Exitosos</span>
              </h1>
              
              <p className="text-xl text-primary-foreground/90">
                Accede a contenido premium, tutoriales exclusivos y estrategias comprobadas que te llevarán al siguiente nivel.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <TrendingUp className="h-8 w-8 text-accent mb-4" />
                <h3 className="font-semibold text-lg mb-2">Estrategias Profesionales</h3>
                <p className="text-sm text-primary-foreground/80">
                  Aprende de traders experimentados con track record comprobado
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <DollarSign className="h-8 w-8 text-accent mb-4" />
                <h3 className="font-semibold text-lg mb-2">ROI Garantizado</h3>
                <p className="text-sm text-primary-foreground/80">
                  Metodologías que han generado retornos consistentes del +150%
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <Shield className="h-8 w-8 text-accent mb-4" />
                <h3 className="font-semibold text-lg mb-2">Plataforma Segura</h3>
                <p className="text-sm text-primary-foreground/80">
                  Pago 100% seguro mediante MercadoPago con acceso inmediato
                </p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                <Users className="h-8 w-8 text-accent mb-4" />
                <h3 className="font-semibold text-lg mb-2">Comunidad Activa</h3>
                <p className="text-sm text-primary-foreground/80">
                  Más de 1000 estudiantes activos con soporte 24/7
                </p>
              </div>
            </div>

            <div className="bg-accent/20 border border-accent/40 rounded-xl p-6">
              <div className="flex items-center space-x-3 mb-4">
                <Award className="h-6 w-6 text-accent" />
                <span className="font-semibold text-lg">Oferta Especial</span>
              </div>
              <p className="text-primary-foreground/90 mb-2">
                Acceso completo a todo el contenido premium por solo <span className="font-bold text-accent text-xl">$2000 ARS</span>
              </p>
              <p className="text-sm text-primary-foreground/80">
                Incluye: Todos los cursos, eBooks, tutoriales de plataformas y calculadoras interactivas
              </p>
            </div>
          </div>

          {/* Auth Forms */}
          <div className="w-full max-w-md mx-auto">
            <Card className="shadow-2xl border-0 bg-background/95 backdrop-blur">
              <CardHeader className="space-y-1 text-center">
                <CardTitle className="text-2xl font-bold">Bienvenido</CardTitle>
                <CardDescription>
                  Inicia sesión o crea tu cuenta para comenzar tu journey en trading
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 mb-6">
                    <TabsTrigger value="login" data-testid="tab-login">Iniciar Sesión</TabsTrigger>
                    <TabsTrigger value="register" data-testid="tab-register">Registrarse</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="login">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="login-email">Email</Label>
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="tu@email.com"
                          value={loginForm.email}
                          onChange={(e) => {
                            setLoginForm({ ...loginForm, email: e.target.value });
                            if (errors.email) setErrors({ ...errors, email: "" });
                          }}
                          data-testid="input-login-email"
                        />
                        {errors.email && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.email}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="login-password">Contraseña</Label>
                        <Input
                          id="login-password"
                          type="password"
                          placeholder="••••••••"
                          value={loginForm.password}
                          onChange={(e) => {
                            setLoginForm({ ...loginForm, password: e.target.value });
                            if (errors.password) setErrors({ ...errors, password: "" });
                          }}
                          data-testid="input-login-password"
                        />
                        {errors.password && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.password}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={loginMutation.isPending}
                        data-testid="button-login-submit"
                      >
                        {loginMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : null}
                        Iniciar Sesión
                      </Button>
                      
                      {loginMutation.error && (
                        <Alert variant="destructive" data-testid="alert-login-error">
                          <AlertDescription>{loginMutation.error.message}</AlertDescription>
                        </Alert>
                      )}
                    </form>
                  </TabsContent>
                  
                  <TabsContent value="register">
                    <form onSubmit={handleRegister} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="register-username">Nombre de Usuario</Label>
                        <Input
                          id="register-username"
                          type="text"
                          placeholder="tu_username"
                          value={registerForm.username}
                          onChange={(e) => {
                            setRegisterForm({ ...registerForm, username: e.target.value });
                            if (errors.username) setErrors({ ...errors, username: "" });
                          }}
                          data-testid="input-register-username"
                        />
                        {errors.username && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.username}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-email">Email</Label>
                        <Input
                          id="register-email"
                          type="email"
                          placeholder="tu@email.com"
                          value={registerForm.email}
                          onChange={(e) => {
                            setRegisterForm({ ...registerForm, email: e.target.value });
                            if (errors.email) setErrors({ ...errors, email: "" });
                          }}
                          data-testid="input-register-email"
                        />
                        {errors.email && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.email}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="register-password">Contraseña</Label>
                        <Input
                          id="register-password"
                          type="password"
                          placeholder="••••••••"
                          value={registerForm.password}
                          onChange={(e) => {
                            setRegisterForm({ ...registerForm, password: e.target.value });
                            if (errors.password) setErrors({ ...errors, password: "" });
                          }}
                          data-testid="input-register-password"
                        />
                        {errors.password && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.password}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="confirm-password">Confirmar Contraseña</Label>
                        <Input
                          id="confirm-password"
                          type="password"
                          placeholder="••••••••"
                          value={registerForm.confirmPassword}
                          onChange={(e) => {
                            setRegisterForm({ ...registerForm, confirmPassword: e.target.value });
                            if (errors.confirmPassword) setErrors({ ...errors, confirmPassword: "" });
                          }}
                          data-testid="input-confirm-password"
                        />
                        {errors.confirmPassword && (
                          <Alert variant="destructive">
                            <AlertDescription>{errors.confirmPassword}</AlertDescription>
                          </Alert>
                        )}
                      </div>
                      
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={registerMutation.isPending}
                        data-testid="button-register-submit"
                      >
                        {registerMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : null}
                        Crear Cuenta
                      </Button>
                      
                      {registerMutation.error && (
                        <Alert variant="destructive" data-testid="alert-register-error">
                          <AlertDescription>{registerMutation.error.message}</AlertDescription>
                        </Alert>
                      )}
                    </form>
                  </TabsContent>
                </Tabs>
                
                <div className="mt-6 text-center">
                  <p className="text-sm text-muted-foreground">
                    Al registrarte, aceptas nuestros términos y condiciones de uso
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
