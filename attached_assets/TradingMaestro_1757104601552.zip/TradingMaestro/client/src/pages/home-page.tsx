import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { ConceptCard } from "@/components/trading/concept-card";
import { FibonacciCalculator } from "@/components/trading/fibonacci-calculator";
import { MovingAverageCalculator } from "@/components/trading/moving-average-calculator";
import { CandlestickDemo } from "@/components/trading/candlestick-demo";
import { MercadoPagoCheckout } from "@/components/payment/mercadopago-checkout";
import {
  TrendingUp, TrendingDown, BookOpen, Calculator,
  Smartphone, Users, Shield, Award, Star,
  ChartLine, Layers, Repeat, Gift, ExternalLink
} from "lucide-react";
import type { Course, Ebook, TradingConcept, PlatformTutorial, ReferralLink } from "@shared/schema";

export default function HomePage() {
  const { user } = useAuth();
  const [showPayment, setShowPayment] = useState(false);

  // Fetch courses
  const { data: courses = [] } = useQuery<Course[]>({
    queryKey: ["/api/courses"],
  });

  // Fetch ebooks
  const { data: ebooks = [] } = useQuery<Ebook[]>({
    queryKey: ["/api/ebooks"],
  });

  // Fetch trading concepts
  const { data: tradingConcepts = [] } = useQuery<TradingConcept[]>({
    queryKey: ["/api/trading-concepts"],
  });

  // Fetch platform tutorials
  const { data: platformTutorials = [] } = useQuery<PlatformTutorial[]>({
    queryKey: ["/api/platform-tutorials"],
  });

  // Fetch referral links
  const { data: referralLinks = [] } = useQuery<ReferralLink[]>({
    queryKey: ["/api/referral-links"],
  });

  // Smooth scrolling for navigation
  useEffect(() => {
    const handleAnchorClick = (e: Event) => {
      const target = e.target as HTMLAnchorElement;
      if (target.hash) {
        e.preventDefault();
        const element = document.querySelector(target.hash);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }
    };

    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
      link.addEventListener('click', handleAnchorClick);
    });

    return () => {
      links.forEach(link => {
        link.removeEventListener('click', handleAnchorClick);
      });
    };
  }, []);

  // Get BingX referral link
  const bingxLink = referralLinks.find(link => 
    link.platform.toLowerCase() === 'bingx'
  ) || {
    url: "https://bingx.com/referral-program/THPORK",
    benefits: ["Comisiones reducidas hasta 50%", "Bono de bienvenida hasta $5000 USDT", "Acceso a señales premium"]
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                <ChartLine className="h-6 w-6 text-white" />
              </div>
              <span className="font-bold text-xl">Aprendiendo Trading</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <a href="#cursos" className="text-muted-foreground hover:text-primary transition-colors">
                Cursos
              </a>
              <a href="#conceptos" className="text-muted-foreground hover:text-primary transition-colors">
                Conceptos
              </a>
              <a href="#plataformas" className="text-muted-foreground hover:text-primary transition-colors">
                Plataformas
              </a>
              <a href="#referidos" className="text-muted-foreground hover:text-primary transition-colors">
                Referidos
              </a>
              {user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm">Hola, {user.username}</span>
                  {user.role === 'admin' && (
                    <Button asChild variant="outline" size="sm">
                      <a href="/admin">Admin</a>
                    </Button>
                  )}
                </div>
              ) : (
                <Button asChild>
                  <a href="/auth">Iniciar Sesión</a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-accent text-white">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3csvg%20xmlns%3d%22http%3a%2f%2fwww.w3.org%2f2000%2fsvg%22%20viewBox%3d%220%200%20100%20100%22%3e%3cdefs%3e%3cpattern%20id%3d%22grid%22%20width%3d%2210%22%20height%3d%2210%22%20patternUnits%3d%22userSpaceOnUse%22%3e%3cpath%20d%3d%22M%2010%200%20L%200%200%200%2010%22%20fill%3d%22none%22%20stroke%3d%22white%22%20stroke-width%3d%220.5%22%20opacity%3d%220.1%22%2f%3e%3c%2fpattern%3e%3c%2fdefs%3e%3crect%20width%3d%22100%22%20height%3d%22100%22%20fill%3d%22url%28%2523grid%29%22%2f%3e%3c%2fsvg%3e')] opacity-20"></div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              <h1 className="font-bold text-4xl lg:text-6xl mb-6 leading-tight">
                Domina el
                <span className="text-accent block">Trading</span>
                Profesional
              </h1>
              <p className="text-xl lg:text-2xl mb-8 text-primary-foreground/90">
                Aprende desde conceptos básicos hasta estrategias avanzadas. 
                Cursos completos, eBooks detallados y tutoriales prácticos.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button
                  size="lg"
                  className="bg-accent hover:bg-accent/90 text-accent-foreground text-lg px-8 py-4"
                  onClick={() => setShowPayment(true)}
                  data-testid="button-start-now"
                >
                  <TrendingUp className="mr-2 h-5 w-5" />
                  Comenzar Ahora - $2000 ARS
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="border-2 border-white text-white hover:bg-white hover:text-primary text-lg px-8 py-4"
                  asChild
                  data-testid="button-view-content"
                >
                  <a href="#cursos">
                    <BookOpen className="mr-2 h-5 w-5" />
                    Ver Contenido
                  </a>
                </Button>
              </div>
              
              <div className="flex items-center justify-center lg:justify-start space-x-6 text-sm">
                <div className="flex items-center space-x-2">
                  <Shield className="h-4 w-4 text-accent" />
                  <span>100% Seguro</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users className="h-4 w-4 text-accent" />
                  <span>+1000 Estudiantes</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Award className="h-4 w-4 text-accent" />
                  <span>Garantizado</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="bg-background/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-center mb-6">
                  <div className="text-6xl font-bold text-accent mb-2">+150%</div>
                  <div className="text-lg">ROI Promedio</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold">50+</div>
                    <div className="text-sm opacity-90">Lecciones</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">24/7</div>
                    <div className="text-sm opacity-90">Soporte</div>
                  </div>
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-green-500 text-white px-4 py-2 rounded-lg font-semibold shadow-lg animate-bounce">
                <TrendingUp className="inline mr-2 h-4 w-4" />
                Estrategias Ganadoras
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Modal */}
      {showPayment && (
        <MercadoPagoCheckout
          isOpen={showPayment}
          onClose={() => setShowPayment(false)}
          amount={2000}
          currency="ARS"
        />
      )}

      {/* Stats Section */}
      <section className="py-16 bg-card/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                {courses.length}+
              </div>
              <div className="text-sm text-muted-foreground mt-2">Cursos Premium</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                1000+
              </div>
              <div className="text-sm text-muted-foreground mt-2">Estudiantes</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                95%
              </div>
              <div className="text-sm text-muted-foreground mt-2">Satisfacción</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                24/7
              </div>
              <div className="text-sm text-muted-foreground mt-2">Soporte</div>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section id="cursos" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl lg:text-5xl mb-6">
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Cursos Premium
              </span> de Trading
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Contenido estructurado y detallado para llevarte desde principiante hasta trader profesional
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {courses.length === 0 ? (
              // Default course cards when no courses are available
              <>
                <Card className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-2 hover:border-primary/20">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-primary/10 text-primary">Principiante</Badge>
                      <span className="text-2xl font-bold">$2000</span>
                    </div>
                    <CardTitle className="text-2xl">Fundamentos del Trading</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      Domina los conceptos básicos: tendencias, soportes, resistencias y psicología del mercado.
                    </p>
                    <div className="space-y-3 mb-6">
                      {[
                        "Conceptos básicos de trading",
                        "Análisis de tendencias",
                        "Soportes y resistencias",
                        "Psicología del trader"
                      ].map((feature, idx) => (
                        <div key={idx} className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={() => setShowPayment(true)}
                      data-testid="button-enroll-fundamentals"
                    >
                      Inscribirse Ahora
                    </Button>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-2 border-primary">
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground">MÁS POPULAR</Badge>
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-accent/10 text-accent">Intermedio</Badge>
                      <span className="text-2xl font-bold">$2000</span>
                    </div>
                    <CardTitle className="text-2xl">Análisis Técnico Avanzado</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      Velas japonesas, medias móviles, Fibonacci y estrategias de entrada/salida profesionales.
                    </p>
                    <div className="space-y-3 mb-6">
                      {[
                        "Velas japonesas completo",
                        "Medias móviles y cálculos",
                        "Fibonacci (retrocesos/extensiones)",
                        "Entradas en largo y corto"
                      ].map((feature, idx) => (
                        <div key={idx} className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={() => setShowPayment(true)}
                      data-testid="button-enroll-advanced"
                    >
                      Inscribirse Ahora
                    </Button>
                  </CardContent>
                </Card>

                <Card className="hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-2 hover:border-accent/20">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-secondary/10 text-secondary">Práctico</Badge>
                      <span className="text-2xl font-bold">$2000</span>
                    </div>
                    <CardTitle className="text-2xl">Dominio de Plataformas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">
                      Manejo completo de Binance y BingX, desde registro hasta estrategias avanzadas.
                    </p>
                    <div className="space-y-3 mb-6">
                      {[
                        "Tutorial completo Binance",
                        "Dominio total BingX",
                        "Configuración de trading",
                        "Gestión de riesgo"
                      ].map((feature, idx) => (
                        <div key={idx} className="flex items-center text-sm">
                          <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                          <span>{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button 
                      className="w-full" 
                      onClick={() => setShowPayment(true)}
                      data-testid="button-enroll-platforms"
                    >
                      Inscribirse Ahora
                    </Button>
                  </CardContent>
                </Card>
              </>
            ) : (
              courses.map((course) => (
                <Card key={course.id} className="hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="capitalize">
                        {course.level}
                      </Badge>
                      <span className="text-2xl font-bold">${course.price}</span>
                    </div>
                    <CardTitle>{course.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">{course.description}</p>
                    <Button 
                      className="w-full" 
                      onClick={() => setShowPayment(true)}
                      data-testid={`button-enroll-${course.id}`}
                    >
                      Inscribirse Ahora
                    </Button>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Trading Concepts Section */}
      <section id="conceptos" className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl lg:text-5xl mb-6">
              Conceptos <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Fundamentales</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Explicaciones detalladas con ejemplos prácticos y calculadoras interactivas
            </p>
          </div>

          <Tabs defaultValue="candlesticks" className="w-full">
            <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 mb-8">
              <TabsTrigger value="candlesticks" data-testid="tab-candlesticks">Velas Japonesas</TabsTrigger>
              <TabsTrigger value="moving-averages" data-testid="tab-moving-averages">Medias Móviles</TabsTrigger>
              <TabsTrigger value="fibonacci" data-testid="tab-fibonacci">Fibonacci</TabsTrigger>
              <TabsTrigger value="support-resistance" data-testid="tab-support-resistance">Soportes</TabsTrigger>
            </TabsList>

            <TabsContent value="candlesticks" className="space-y-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-3xl font-bold mb-6">Velas Japonesas</h3>
                  <p className="text-lg text-muted-foreground mb-8">
                    Domina la lectura e interpretación de patrones de velas japonesas. 
                    Aprende a identificar reversiones, continuaciones y puntos de entrada óptimos.
                  </p>
                  
                  <div className="space-y-4">
                    <ConceptCard
                      title="Patrones Básicos"
                      description="Doji, Hammer, Shooting Star, Engulfing"
                      icon={<ChartLine className="h-6 w-6" />}
                    />
                    <ConceptCard
                      title="Señales de Reversión"
                      description="Identifica cambios de tendencia con precisión"
                      icon={<Repeat className="h-6 w-6" />}
                    />
                    <ConceptCard
                      title="Cálculo de Rangos"
                      description="Mide la volatilidad y establece objetivos"
                      icon={<Calculator className="h-6 w-6" />}
                    />
                  </div>
                </div>
                <div>
                  <CandlestickDemo />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="moving-averages" className="space-y-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <MovingAverageCalculator />
                </div>
                <div>
                  <h3 className="text-3xl font-bold mb-6">Medias Móviles</h3>
                  <p className="text-lg text-muted-foreground mb-8">
                    Comprende los diferentes tipos de medias móviles y cómo calcularlas. 
                    Desde simples hasta exponenciales, con fórmulas y aplicaciones prácticas.
                  </p>
                  
                  <div className="space-y-6">
                    <Card className="p-4">
                      <h4 className="font-semibold text-primary mb-2">Media Móvil Simple (SMA)</h4>
                      <p className="text-sm text-muted-foreground mb-2">SMA = (P1 + P2 + ... + Pn) / n</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm">
                        SMA20 = Suma(20 precios) / 20
                      </div>
                    </Card>
                    
                    <Card className="p-4">
                      <h4 className="font-semibold text-accent mb-2">Media Móvil Exponencial (EMA)</h4>
                      <p className="text-sm text-muted-foreground mb-2">EMA = (Precio × α) + (EMA anterior × (1-α))</p>
                      <div className="bg-muted p-3 rounded-lg font-mono text-sm">
                        α = 2 / (periodo + 1)
                      </div>
                    </Card>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="fibonacci" className="space-y-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-3xl font-bold mb-6">Fibonacci</h3>
                  <p className="text-lg text-muted-foreground mb-8">
                    Domina los niveles de Fibonacci para identificar retrocesos y extensiones. 
                    Aprende a aplicar estos niveles clave en tus análisis técnicos.
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    {[
                      { level: "23.6%", type: "Retroceso" },
                      { level: "38.2%", type: "Retroceso" },
                      { level: "61.8%", type: "Retroceso" },
                      { level: "78.6%", type: "Retroceso" }
                    ].map(({ level, type }, idx) => (
                      <Card key={idx} className="p-4 text-center">
                        <div className="text-2xl font-bold text-primary">{level}</div>
                        <div className="text-sm text-muted-foreground">{type}</div>
                      </Card>
                    ))}
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <TrendingDown className="text-red-500 mr-3 h-4 w-4" />
                      <span>Retrocesos: 23.6%, 38.2%, 50%, 61.8%, 78.6%</span>
                    </div>
                    <div className="flex items-center">
                      <TrendingUp className="text-green-500 mr-3 h-4 w-4" />
                      <span>Extensiones: 127.2%, 161.8%, 261.8%</span>
                    </div>
                  </div>
                </div>
                <div>
                  <FibonacciCalculator />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="support-resistance" className="space-y-8">
              <div className="grid lg:grid-cols-2 gap-8 items-center">
                <div>
                  <Card className="p-8">
                    <h4 className="font-semibold mb-4">Niveles Clave</h4>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                        <span className="font-medium">Resistencia</span>
                        <span className="text-sm text-red-600 font-medium">Zona de venta</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                        <span className="font-medium">Soporte</span>
                        <span className="text-sm text-green-600 font-medium">Zona de compra</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <span className="font-medium">Ruptura</span>
                        <span className="text-sm text-blue-600 font-medium">Confirmación</span>
                      </div>
                    </div>
                  </Card>
                </div>
                <div>
                  <h3 className="text-3xl font-bold mb-6">Soporte y Resistencia</h3>
                  <p className="text-lg text-muted-foreground mb-8">
                    Identificación de niveles clave, zonas de interés y puntos de entrada/salida.
                  </p>
                  
                  <div className="space-y-4">
                    <ConceptCard
                      title="Soporte Dinámico"
                      description="Medias móviles como soporte en tendencias alcistas"
                      icon={<Layers className="h-6 w-6" />}
                    />
                    <ConceptCard
                      title="Resistencia Clave"
                      description="Máximos anteriores y niveles psicológicos"
                      icon={<TrendingUp className="h-6 w-6" />}
                    />
                    <ConceptCard
                      title="Rupturas"
                      description="Confirmación con volumen y seguimiento"
                      icon={<TrendingDown className="h-6 w-6" />}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Platform Tutorials Section */}
      <section id="plataformas" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl lg:text-5xl mb-6">
              Domina las <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Plataformas</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Tutoriales completos para operar en las mejores plataformas de trading
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Binance Tutorial */}
            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-yellow-500 rounded-2xl flex items-center justify-center">
                  <span className="text-black font-bold text-xl">B</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Binance</h3>
                  <p className="text-muted-foreground">El exchange más grande del mundo</p>
                </div>
              </div>
              
              <p className="text-muted-foreground mb-6">
                Aprende desde cero a operar en Binance. Registro, verificación, depósitos, 
                trading spot, futuros y configuraciones avanzadas.
              </p>

              <div className="space-y-4 mb-6">
                {[
                  "Registro y verificación",
                  "Trading Spot y Futuros", 
                  "Configuración de stop loss",
                  "Análisis técnico integrado"
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <span className="text-sm">{feature}</span>
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  </div>
                ))}
              </div>

              <Button 
                className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-black"
                onClick={() => setShowPayment(true)}
                data-testid="button-binance-tutorial"
              >
                <Smartphone className="mr-2 h-4 w-4" />
                Ver Tutorial Completo
              </Button>
            </Card>

            {/* BingX Tutorial */}
            <Card className="p-8 hover:shadow-xl transition-all duration-300 transform hover:scale-105 border-2 border-primary relative">
              <div className="absolute -top-3 left-6">
                <Badge className="bg-primary text-primary-foreground">RECOMENDADO</Badge>
              </div>
              
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-2xl flex items-center justify-center">
                  <ChartLine className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">BingX</h3>
                  <p className="text-primary font-medium">Trading social y copy trading</p>
                </div>
              </div>
              
              <p className="text-muted-foreground mb-6">
                Domina BingX desde básico hasta avanzado. Copy trading, señales sociales, 
                derivados y gestión de riesgo profesional.
              </p>

              <div className="space-y-4 mb-6">
                {[
                  "Configuración inicial",
                  "Copy Trading profesional",
                  "Trading de derivados", 
                  "Análisis de traders top"
                ].map((feature, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-primary/10 rounded-lg">
                    <span className="text-sm">{feature}</span>
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                ))}
              </div>

              <Button 
                className="w-full"
                onClick={() => setShowPayment(true)}
                data-testid="button-bingx-tutorial"
              >
                <Users className="mr-2 h-4 w-4" />
                Acceder a BingX Masterclass
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* Referral Section */}
      <section id="referidos" className="py-20 bg-gradient-to-br from-accent/20 via-background to-primary/10">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="font-bold text-4xl lg:text-5xl mb-6">
              Enlaces de <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Referido</span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Usa nuestros enlaces oficiales para obtener beneficios exclusivos en las mejores plataformas
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            {/* BingX Referral - Featured */}
            <Card className="p-8 mb-8 border-2 border-accent relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/20 rounded-full -translate-y-16 translate-x-16"></div>
              <div className="absolute bottom-0 left-0 w-24 h-24 bg-accent/20 rounded-full translate-y-12 -translate-x-12"></div>
              
              <div className="grid lg:grid-cols-2 gap-8 items-center relative z-10">
                <div>
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-2xl flex items-center justify-center">
                      <Gift className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-3xl font-bold">BingX Oficial</h3>
                      <p className="text-accent font-medium text-lg">Enlace de Referido Premium</p>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-6">
                    {(bingxLink.benefits as string[] || []).map((benefit, idx) => (
                      <div key={idx} className="flex items-center space-x-3">
                        <Gift className="h-5 w-5 text-accent" />
                        <span className="font-medium">{benefit}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="bg-accent/10 border border-accent rounded-lg p-4 mb-6">
                    <div className="font-mono text-sm break-all" data-testid="text-bingx-referral-url">
                      {bingxLink.url}
                    </div>
                  </div>
                  
                  <Button 
                    className="bg-accent hover:bg-accent/90 text-accent-foreground"
                    size="lg"
                    asChild
                    data-testid="button-bingx-referral"
                  >
                    <a href={bingxLink.url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="mr-2 h-5 w-5" />
                      Registrarse en BingX
                    </a>
                  </Button>
                </div>
                
                <div className="text-center">
                  <div className="bg-gradient-to-br from-primary to-accent rounded-2xl p-8 text-white mb-6">
                    <h4 className="text-2xl font-bold mb-4">Beneficios Exclusivos</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-3xl font-bold">50%</div>
                        <div className="text-sm opacity-90">Descuento</div>
                      </div>
                      <div>
                        <div className="text-3xl font-bold">$5K</div>
                        <div className="text-sm opacity-90">Bonus</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <Card className="p-4">
                      <div className="font-bold text-2xl text-accent">24/7</div>
                      <div className="text-sm text-muted-foreground">Soporte</div>
                    </Card>
                    <Card className="p-4">
                      <div className="font-bold text-2xl text-green-500">150+</div>
                      <div className="text-sm text-muted-foreground">Criptomonedas</div>
                    </Card>
                  </div>
                </div>
              </div>
            </Card>
            
            {/* Additional Referral Benefits */}
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="p-6 text-center hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-semibold text-lg mb-2">Comisiones Reducidas</h4>
                <p className="text-sm text-muted-foreground">Ahorra en cada operación con descuentos exclusivos</p>
              </Card>
              
              <Card className="p-6 text-center hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-semibold text-lg mb-2">Activación Rápida</h4>
                <p className="text-sm text-muted-foreground">Beneficios aplicados automáticamente al registrarse</p>
              </Card>
              
              <Card className="p-6 text-center hover:shadow-lg transition-all duration-300">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <h4 className="font-semibold text-lg mb-2">Soporte VIP</h4>
                <p className="text-sm text-muted-foreground">Atención personalizada y resolución prioritaria</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg flex items-center justify-center">
                  <ChartLine className="h-6 w-6 text-white" />
                </div>
                <span className="font-bold text-xl">Aprendiendo Trading</span>
              </div>
              <p className="text-gray-400 mb-6">
                La plataforma más completa para aprender trading profesional desde cero hasta nivel avanzado.
              </p>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-lg mb-6">Enlaces Rápidos</h4>
              <div className="space-y-3">
                <a href="#cursos" className="block text-gray-400 hover:text-white transition-colors">Cursos</a>
                <a href="#conceptos" className="block text-gray-400 hover:text-white transition-colors">Conceptos Básicos</a>
                <a href="#plataformas" className="block text-gray-400 hover:text-white transition-colors">Tutoriales Apps</a>
                <a href="#referidos" className="block text-gray-400 hover:text-white transition-colors">Enlaces Referidos</a>
              </div>
            </div>
            
            {/* Resources */}
            <div>
              <h4 className="font-semibold text-lg mb-6">Recursos</h4>
              <div className="space-y-3">
                <span className="block text-gray-400">eBooks Premium</span>
                <span className="block text-gray-400">Calculadoras</span>
                <span className="block text-gray-400">Análisis de Mercado</span>
                <span className="block text-gray-400">Soporte 24/7</span>
              </div>
            </div>
            
            {/* Contact Info */}
            <div>
              <h4 className="font-semibold text-lg mb-6">Información de Pago</h4>
              <div className="space-y-3">
                <div>
                  <div className="text-sm text-gray-400">CVU MercadoPago:</div>
                  <div className="font-mono text-sm" data-testid="text-cvu">0000003100041434897381</div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Titular:</div>
                  <div data-testid="text-account-holder">Jeremias062009</div>
                </div>
                <div>
                  <div className="text-sm text-gray-400">Monto Mínimo:</div>
                  <div className="font-bold text-accent" data-testid="text-minimum-amount">$2000 ARS</div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p className="text-gray-400">
              © 2024 Aprendiendo Trading. Todos los derechos reservados. 
              <span className="text-accent ml-2">Trading educativo profesional.</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
