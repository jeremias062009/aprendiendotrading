# Trading Education Platform

## Overview

This is a comprehensive trading education platform built with React, Express, and PostgreSQL. The application provides structured trading courses, interactive calculators, educational content, and payment processing capabilities. It features a modern UI built with shadcn/ui components and includes both user-facing content and administrative management tools.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React with TypeScript**: Modern component-based architecture using functional components and hooks
- **Vite**: Fast build tool and development server with hot module replacement
- **UI Framework**: shadcn/ui components based on Radix UI primitives with Tailwind CSS styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation for type-safe form handling

### Backend Architecture
- **Express.js**: RESTful API server with TypeScript support
- **Authentication**: Passport.js with local strategy and session-based authentication
- **Session Management**: Express sessions with PostgreSQL session store
- **API Structure**: Organized route handlers with middleware for authentication and authorization
- **Error Handling**: Centralized error handling with structured error responses

### Database Design
- **PostgreSQL**: Primary database using Drizzle ORM for type-safe database operations
- **Schema**: Comprehensive schema including users, payments, courses, ebooks, trading concepts, platform tutorials, and referral links
- **Migration System**: Drizzle Kit for database schema migrations and management
- **Connection Pooling**: Neon serverless PostgreSQL with connection pooling

### Authentication & Authorization
- **Session-based Authentication**: Secure session management with PostgreSQL session store
- **Role-based Access Control**: User and admin roles with protected routes
- **Password Security**: Scrypt-based password hashing with salt
- **Access Control**: Middleware for protecting admin routes and premium content

### Content Management System
- **Multi-type Content**: Support for courses, ebooks, trading concepts, platform tutorials, and referral links
- **Admin Dashboard**: Comprehensive content management interface for admins
- **Content Editor**: Rich content creation and editing capabilities
- **Active/Inactive States**: Content visibility control

### Payment Processing
- **MercadoPago Integration**: Payment processing for course access
- **Payment Tracking**: Complete payment lifecycle management with status tracking
- **Access Control**: Automatic access provisioning upon successful payment

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **passport**: Authentication middleware for Express
- **express-session**: Session management for Express
- **connect-pg-simple**: PostgreSQL session store

### UI Dependencies
- **@radix-ui/**: Component primitives for accessible UI components
- **@tanstack/react-query**: Server state management and caching
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Utility for managing component variants
- **lucide-react**: Icon library

### Development Tools
- **vite**: Build tool and development server
- **typescript**: Type safety and development experience
- **tsx**: TypeScript execution for Node.js
- **drizzle-kit**: Database migration and management tool

### Validation & Forms
- **zod**: Schema validation library
- **react-hook-form**: Form state management
- **@hookform/resolvers**: Form validation resolvers

### Date & Utility Libraries
- **date-fns**: Date manipulation library
- **clsx**: Conditional className utility
- **nanoid**: Unique ID generation