import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { insertPaymentSchema, insertCourseSchema, insertEbookSchema, insertTradingConceptSchema, insertPlatformTutorialSchema, insertReferralLinkSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  // Setup authentication routes
  setupAuth(app);

  // Middleware to check admin role
  const requireAdmin = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };

  // Middleware to check user has access (paid)
  const requireAccess = (req: any, res: any, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    if (!req.user.hasAccess) {
      return res.status(403).json({ message: "Payment required to access this content" });
    }
    next();
  };

  // Payment routes
  app.post("/api/payments", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Authentication required" });
      }

      const paymentData = insertPaymentSchema.parse({
        ...req.body,
        userId: req.user!.id,
      });

      const payment = await storage.createPayment(paymentData);
      res.status(201).json(payment);
    } catch (error: any) {
      console.error('Payment creation error:', error);
      res.status(400).json({ message: error.message || "Error creating payment" });
    }
  });

  app.post("/api/payments/:id/confirm", async (req, res) => {
    try {
      const { id } = req.params;
      const { status, mercadopagoId } = req.body;

      const payment = await storage.updatePaymentStatus(id, status, mercadopagoId);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }

      // If payment is completed and amount is sufficient, grant access
      if (status === 'completed' && parseFloat(payment.amount) >= 2000) {
        await storage.updateUserAccess(payment.userId, true);
      }

      res.json(payment);
    } catch (error: any) {
      console.error('Payment confirmation error:', error);
      res.status(400).json({ message: error.message || "Error confirming payment" });
    }
  });

  // Course routes
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching courses" });
    }
  });

  app.get("/api/courses/:id", requireAccess, async (req, res) => {
    try {
      const { id } = req.params;
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching course" });
    }
  });

  app.post("/api/courses", requireAdmin, async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(courseData);
      res.status(201).json(course);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error creating course" });
    }
  });

  app.put("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const courseData = insertCourseSchema.partial().parse(req.body);
      const course = await storage.updateCourse(id, courseData);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json(course);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error updating course" });
    }
  });

  app.delete("/api/courses/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteCourse(id);
      if (!deleted) {
        return res.status(404).json({ message: "Course not found" });
      }
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error deleting course" });
    }
  });

  // Ebook routes
  app.get("/api/ebooks", async (req, res) => {
    try {
      const ebooks = await storage.getAllEbooks();
      res.json(ebooks);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching ebooks" });
    }
  });

  app.get("/api/ebooks/:id", requireAccess, async (req, res) => {
    try {
      const { id } = req.params;
      const ebook = await storage.getEbook(id);
      if (!ebook) {
        return res.status(404).json({ message: "Ebook not found" });
      }
      res.json(ebook);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching ebook" });
    }
  });

  app.post("/api/ebooks", requireAdmin, async (req, res) => {
    try {
      const ebookData = insertEbookSchema.parse(req.body);
      const ebook = await storage.createEbook(ebookData);
      res.status(201).json(ebook);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error creating ebook" });
    }
  });

  // Trading concepts routes
  app.get("/api/trading-concepts", async (req, res) => {
    try {
      const { category } = req.query;
      const concepts = category 
        ? await storage.getTradingConceptsByCategory(category as string)
        : await storage.getAllTradingConcepts();
      res.json(concepts);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching trading concepts" });
    }
  });

  app.get("/api/trading-concepts/:id", requireAccess, async (req, res) => {
    try {
      const { id } = req.params;
      const concept = await storage.getTradingConcept(id);
      if (!concept) {
        return res.status(404).json({ message: "Trading concept not found" });
      }
      res.json(concept);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching trading concept" });
    }
  });

  app.post("/api/trading-concepts", requireAdmin, async (req, res) => {
    try {
      const conceptData = insertTradingConceptSchema.parse(req.body);
      const concept = await storage.createTradingConcept(conceptData);
      res.status(201).json(concept);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error creating trading concept" });
    }
  });

  // Platform tutorials routes
  app.get("/api/platform-tutorials", async (req, res) => {
    try {
      const { platform } = req.query;
      const tutorials = platform
        ? await storage.getTutorialsByPlatform(platform as string)
        : await storage.getAllPlatformTutorials();
      res.json(tutorials);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching tutorials" });
    }
  });

  app.get("/api/platform-tutorials/:id", requireAccess, async (req, res) => {
    try {
      const { id } = req.params;
      const tutorial = await storage.getPlatformTutorial(id);
      if (!tutorial) {
        return res.status(404).json({ message: "Tutorial not found" });
      }
      res.json(tutorial);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching tutorial" });
    }
  });

  app.post("/api/platform-tutorials", requireAdmin, async (req, res) => {
    try {
      const tutorialData = insertPlatformTutorialSchema.parse(req.body);
      const tutorial = await storage.createPlatformTutorial(tutorialData);
      res.status(201).json(tutorial);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error creating tutorial" });
    }
  });

  // Referral links routes
  app.get("/api/referral-links", async (req, res) => {
    try {
      const links = await storage.getAllReferralLinks();
      res.json(links);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching referral links" });
    }
  });

  app.post("/api/referral-links", requireAdmin, async (req, res) => {
    try {
      const linkData = insertReferralLinkSchema.parse(req.body);
      const link = await storage.createReferralLink(linkData);
      res.status(201).json(link);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Error creating referral link" });
    }
  });

  // Admin dashboard stats
  app.get("/api/admin/stats", requireAdmin, async (req, res) => {
    try {
      // This is a placeholder - implement actual stats gathering
      const stats = {
        totalUsers: 1247,
        totalCourses: 45,
        totalRevenue: 127000,
        satisfaction: 94
      };
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Error fetching stats" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
