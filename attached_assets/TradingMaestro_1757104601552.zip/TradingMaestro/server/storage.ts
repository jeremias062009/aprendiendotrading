import { users, payments, courses, ebooks, tradingConcepts, platformTutorials, referralLinks } from "@shared/schema";
import type { 
  User, InsertUser, Payment, InsertPayment, Course, InsertCourse,
  Ebook, InsertEbook, TradingConcept, InsertTradingConcept,
  PlatformTutorial, InsertPlatformTutorial, ReferralLink, InsertReferralLink
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserAccess(id: string, hasAccess: boolean): Promise<User | undefined>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: string, status: string, mercadopagoId?: string): Promise<Payment | undefined>;
  getPaymentsByUser(userId: string): Promise<Payment[]>;

  // Course operations
  getAllCourses(): Promise<Course[]>;
  getCourse(id: string): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: string): Promise<boolean>;

  // Ebook operations
  getAllEbooks(): Promise<Ebook[]>;
  getEbook(id: string): Promise<Ebook | undefined>;
  createEbook(ebook: InsertEbook): Promise<Ebook>;
  updateEbook(id: string, ebook: Partial<InsertEbook>): Promise<Ebook | undefined>;
  deleteEbook(id: string): Promise<boolean>;

  // Trading concept operations
  getAllTradingConcepts(): Promise<TradingConcept[]>;
  getTradingConceptsByCategory(category: string): Promise<TradingConcept[]>;
  getTradingConcept(id: string): Promise<TradingConcept | undefined>;
  createTradingConcept(concept: InsertTradingConcept): Promise<TradingConcept>;
  updateTradingConcept(id: string, concept: Partial<InsertTradingConcept>): Promise<TradingConcept | undefined>;
  deleteTradingConcept(id: string): Promise<boolean>;

  // Platform tutorial operations
  getAllPlatformTutorials(): Promise<PlatformTutorial[]>;
  getTutorialsByPlatform(platform: string): Promise<PlatformTutorial[]>;
  getPlatformTutorial(id: string): Promise<PlatformTutorial | undefined>;
  createPlatformTutorial(tutorial: InsertPlatformTutorial): Promise<PlatformTutorial>;
  updatePlatformTutorial(id: string, tutorial: Partial<InsertPlatformTutorial>): Promise<PlatformTutorial | undefined>;
  deletePlatformTutorial(id: string): Promise<boolean>;

  // Referral link operations
  getAllReferralLinks(): Promise<ReferralLink[]>;
  getReferralLink(id: string): Promise<ReferralLink | undefined>;
  createReferralLink(link: InsertReferralLink): Promise<ReferralLink>;
  updateReferralLink(id: string, link: Partial<InsertReferralLink>): Promise<ReferralLink | undefined>;
  deleteReferralLink(id: string): Promise<boolean>;

  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUserAccess(id: string, hasAccess: boolean): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ hasAccess, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  // Payment operations
  async createPayment(payment: InsertPayment): Promise<Payment> {
    const [newPayment] = await db
      .insert(payments)
      .values(payment)
      .returning();
    return newPayment;
  }

  async updatePaymentStatus(id: string, status: string, mercadopagoId?: string): Promise<Payment | undefined> {
    const updateData: any = { status, updatedAt: new Date() };
    if (mercadopagoId) {
      updateData.mercadopagoId = mercadopagoId;
    }

    const [payment] = await db
      .update(payments)
      .set(updateData)
      .where(eq(payments.id, id))
      .returning();
    return payment || undefined;
  }

  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(desc(payments.createdAt));
  }

  // Course operations
  async getAllCourses(): Promise<Course[]> {
    return await db.select().from(courses).where(eq(courses.isActive, true)).orderBy(desc(courses.createdAt));
  }

  async getCourse(id: string): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course || undefined;
  }

  async createCourse(course: InsertCourse): Promise<Course> {
    const [newCourse] = await db
      .insert(courses)
      .values(course)
      .returning();
    return newCourse;
  }

  async updateCourse(id: string, course: Partial<InsertCourse>): Promise<Course | undefined> {
    const [updated] = await db
      .update(courses)
      .set({ ...course, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteCourse(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(courses)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(courses.id, id))
      .returning();
    return !!deleted;
  }

  // Ebook operations
  async getAllEbooks(): Promise<Ebook[]> {
    return await db.select().from(ebooks).where(eq(ebooks.isActive, true)).orderBy(desc(ebooks.createdAt));
  }

  async getEbook(id: string): Promise<Ebook | undefined> {
    const [ebook] = await db.select().from(ebooks).where(eq(ebooks.id, id));
    return ebook || undefined;
  }

  async createEbook(ebook: InsertEbook): Promise<Ebook> {
    const [newEbook] = await db
      .insert(ebooks)
      .values(ebook)
      .returning();
    return newEbook;
  }

  async updateEbook(id: string, ebook: Partial<InsertEbook>): Promise<Ebook | undefined> {
    const [updated] = await db
      .update(ebooks)
      .set({ ...ebook, updatedAt: new Date() })
      .where(eq(ebooks.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteEbook(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(ebooks)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(ebooks.id, id))
      .returning();
    return !!deleted;
  }

  // Trading concept operations
  async getAllTradingConcepts(): Promise<TradingConcept[]> {
    return await db.select().from(tradingConcepts).where(eq(tradingConcepts.isActive, true)).orderBy(desc(tradingConcepts.createdAt));
  }

  async getTradingConceptsByCategory(category: string): Promise<TradingConcept[]> {
    return await db
      .select()
      .from(tradingConcepts)
      .where(eq(tradingConcepts.category, category))
      .orderBy(desc(tradingConcepts.createdAt));
  }

  async getTradingConcept(id: string): Promise<TradingConcept | undefined> {
    const [concept] = await db.select().from(tradingConcepts).where(eq(tradingConcepts.id, id));
    return concept || undefined;
  }

  async createTradingConcept(concept: InsertTradingConcept): Promise<TradingConcept> {
    const [newConcept] = await db
      .insert(tradingConcepts)
      .values(concept)
      .returning();
    return newConcept;
  }

  async updateTradingConcept(id: string, concept: Partial<InsertTradingConcept>): Promise<TradingConcept | undefined> {
    const [updated] = await db
      .update(tradingConcepts)
      .set({ ...concept, updatedAt: new Date() })
      .where(eq(tradingConcepts.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteTradingConcept(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(tradingConcepts)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(tradingConcepts.id, id))
      .returning();
    return !!deleted;
  }

  // Platform tutorial operations
  async getAllPlatformTutorials(): Promise<PlatformTutorial[]> {
    return await db.select().from(platformTutorials).where(eq(platformTutorials.isActive, true)).orderBy(desc(platformTutorials.createdAt));
  }

  async getTutorialsByPlatform(platform: string): Promise<PlatformTutorial[]> {
    return await db
      .select()
      .from(platformTutorials)
      .where(eq(platformTutorials.platform, platform))
      .orderBy(desc(platformTutorials.createdAt));
  }

  async getPlatformTutorial(id: string): Promise<PlatformTutorial | undefined> {
    const [tutorial] = await db.select().from(platformTutorials).where(eq(platformTutorials.id, id));
    return tutorial || undefined;
  }

  async createPlatformTutorial(tutorial: InsertPlatformTutorial): Promise<PlatformTutorial> {
    const [newTutorial] = await db
      .insert(platformTutorials)
      .values(tutorial)
      .returning();
    return newTutorial;
  }

  async updatePlatformTutorial(id: string, tutorial: Partial<InsertPlatformTutorial>): Promise<PlatformTutorial | undefined> {
    const [updated] = await db
      .update(platformTutorials)
      .set({ ...tutorial, updatedAt: new Date() })
      .where(eq(platformTutorials.id, id))
      .returning();
    return updated || undefined;
  }

  async deletePlatformTutorial(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(platformTutorials)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(platformTutorials.id, id))
      .returning();
    return !!deleted;
  }

  // Referral link operations
  async getAllReferralLinks(): Promise<ReferralLink[]> {
    return await db.select().from(referralLinks).where(eq(referralLinks.isActive, true)).orderBy(desc(referralLinks.createdAt));
  }

  async getReferralLink(id: string): Promise<ReferralLink | undefined> {
    const [link] = await db.select().from(referralLinks).where(eq(referralLinks.id, id));
    return link || undefined;
  }

  async createReferralLink(link: InsertReferralLink): Promise<ReferralLink> {
    const [newLink] = await db
      .insert(referralLinks)
      .values(link)
      .returning();
    return newLink;
  }

  async updateReferralLink(id: string, link: Partial<InsertReferralLink>): Promise<ReferralLink | undefined> {
    const [updated] = await db
      .update(referralLinks)
      .set({ ...link, updatedAt: new Date() })
      .where(eq(referralLinks.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteReferralLink(id: string): Promise<boolean> {
    const [deleted] = await db
      .update(referralLinks)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(referralLinks.id, id))
      .returning();
    return !!deleted;
  }
}

export const storage = new DatabaseStorage();
